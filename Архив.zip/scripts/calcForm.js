const form = document.getElementById('calcForm')

function validateForm() {
    let formReq = document.querySelectorAll('._req')

    for (let i = 0; i < formReq.length; i++) {
        const input = formReq[i]

        formRemErr(input)

        if (
            input.getAttribute('type') === 'checkbox' &&
            input.checked === false
        ) {
            formAddErr(input)
            alert('Заполните все поля')
            return false
        } else if (input.value.trim() === '') {
            formAddErr(input)
            alert('Заполните все поля')
            return false
        }
    }

    function formAddErr(input) {
        input.classList.add('_error')
    }
    function formRemErr(input) {
        input.classList.remove('_error')
    }
}
